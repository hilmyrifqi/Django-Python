from django.contrib import admin

# Register your models here.

from . models import Sertifikasi

class ModifikasiAdmin(admin.ModelAdmin):
    list_display = ('sertifikasi', 'materi')

admin.site.register(Sertifikasi, ModifikasiAdmin)