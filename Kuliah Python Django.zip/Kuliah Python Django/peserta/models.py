from django.db import models

# Create your models here.

from sertifikasi.models import Sertifikasi

class Peserta(models.Model):
    nim = models.CharField(max_length=100)
    nama = models.CharField(max_length=100)
    sertifikasi = models.ForeignKey(Sertifikasi, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.nim