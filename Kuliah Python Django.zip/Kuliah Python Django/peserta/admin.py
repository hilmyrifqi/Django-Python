from django.contrib import admin

# Register your models here.

from . models import Peserta

class ModifikasiAdmin(admin.ModelAdmin):
    list_display = ('nim', 'nama', 'sertifikasi')

admin.site.register(Peserta, ModifikasiAdmin)