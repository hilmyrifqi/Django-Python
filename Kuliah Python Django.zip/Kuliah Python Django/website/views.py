from django.shortcuts import render

from sertifikasi.models import Sertifikasi
from peserta.models import Peserta

def index(request):
    tampungSertifikasi = Sertifikasi.objects.all()

    context ={
        'TS':tampungSertifikasi,
    }

    return render(request, 'index.html', context)

def peserta(request):
    tampungPeserta = Peserta.objects.all()

    context = {
        'TP':tampungPeserta,
    }
    
    return render(request, 'peserta.html', context)